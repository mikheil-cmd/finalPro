package com.example.finalproject

data class Category(
    val category_id: Int,
    val category_name: String,
    val category_image_path: String
)