package com.example.finalproject

data class ApiResponse(
    val message: String
)